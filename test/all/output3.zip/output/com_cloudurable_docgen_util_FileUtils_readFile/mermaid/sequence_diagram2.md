----
# FIX RAW RESPONSE 3
# Participants After Fix

1. FileUtils
2. IOException
3. RuntimeException

# Interaction After Fix

- FileUtils->>File: Read File
- alt File exists
    - File->>FileUtils: Return File Contents
- else File does not exist
    - File->>IOException: Throw IOException
    - IOException-->>RuntimeException: Handle Error
- end

# Final Participants

1. FileUtils
2. IOException
3. RuntimeException

# Plain English Title

Read File

# Mermaid Sequence Diagram

```mermaid
---
title: Read File
---

sequenceDiagram
    participant FileUtils
    participant IOException
    participant RuntimeException

    FileUtils->>File: Read File
    alt File exists
        File->>FileUtils: Return File Contents
    else File does not exist
        File->>IOException: Throw IOException
        IOException-->>RuntimeException: Handle Error
    end
```

End of instructions.