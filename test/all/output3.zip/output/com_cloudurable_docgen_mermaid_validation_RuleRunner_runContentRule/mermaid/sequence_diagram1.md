----
# ORIGINAL RESPONSE 
# Participants

- RuleRunner
- LineRule
- ContentRule
- RuleResult

# Initial Interactions

- RuleRunner calls `runContentRule` method with `content` parameter
- RuleRunner initializes an empty `results` list
- RuleRunner iterates over each `ContentRule` in `contentRules`
- For each `ContentRule`, RuleRunner calls `check` method with `content` parameter
- If the `RuleResult` is not `SUCCESS`, RuleRunner adds the `result` to the `results` list

# Clean Interactions

- RuleRunner -> ContentRule: check content (for each ContentRule)
    - alt result != SUCCESS
        - RuleRunner --> RuleResult: Add result to results list
    - end

# Final Participants

- RuleRunner
    - RuleRunner -> ContentRule: check content (for each ContentRule)
- ContentRule
    - RuleRunner -> ContentRule: check content (for each ContentRule)
    - RuleRunner --> RuleResult: Add result to results list
- RuleResult
    - RuleRunner --> RuleResult: Add result to results list

# Plain English Title

runContentRule

# Mermaid Sequence Diagram

```mermaid
---
title: runContentRule
---

sequenceDiagram
    participant RuleRunner
    participant ContentRule
    participant RuleResult

    RuleRunner->>ContentRule: check content (for each ContentRule)
    alt result != SUCCESS
        RuleRunner-->>RuleResult: Add result to results list
    end
```
