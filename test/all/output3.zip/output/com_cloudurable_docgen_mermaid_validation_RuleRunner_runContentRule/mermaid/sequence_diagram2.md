----
# FIX RAW RESPONSE 3
# Participants After Fix

1. RuleRunner
2. ContentRule
3. RuleResult

# Validation Fixes

## No Method Calls In Descriptions Rule
Instead of `RuleRunner->>ContentRule: check content (for each ContentRule)`, use `RuleRunner->>ContentRule: Check content for each ContentRule`.

# Interaction After Fix

```plaintext
RuleRunner->>ContentRule: Check content for each ContentRule
alt result != SUCCESS
    RuleRunner-->>RuleResult: Add result to results list
end
```

# Final Participants

1. RuleRunner
2. ContentRule
3. RuleResult

# Plain English Title

"Run Content Rule"

# Mermaid Sequence Diagram

```mermaid
---
title: Run Content Rule
---

sequenceDiagram
    participant RuleRunner
    participant ContentRule
    participant RuleResult
    
    RuleRunner->>ContentRule: Check content for each ContentRule
    alt result != SUCCESS
        RuleRunner-->>RuleResult: Add result to results list
    end
```

End of instructions.