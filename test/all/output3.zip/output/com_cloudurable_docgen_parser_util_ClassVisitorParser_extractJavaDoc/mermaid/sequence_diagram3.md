----
# FIX RAW RESPONSE 2
# Final Participants

1. ClassVisitorParser
2. Matcher
3. String

# Validation Fixes

1. Fix issue with `Matcher` being considered as a participant. Exclude it from the list of participants.

# Interaction After Fix

1. ClassVisitorParser->>Matcher: Define Javadoc regex pattern
2. Matcher->>String: Find Javadoc comment in code
3. alt Javadoc comment found
    4. Matcher->>String: Extract Javadoc comment
    5. Matcher->>int: Get ending position of Javadoc comment
    6. Matcher->>String: Extract method code
    7. Matcher->>String[]: Return Javadoc comment and method code
8. else Javadoc comment not found
    9. Matcher->>String[]: Return empty Javadoc comment and original code
10. ClassVisitorParser->>Matcher: Matcher object

# Plain English Title

Extract JavaDoc

# Mermaid Sequence Diagram

```mermaid
---
title: Extract JavaDoc
---

sequenceDiagram
    ClassVisitorParser->>Matcher: Define Javadoc regex pattern
    ClassVisitorParser->>Matcher: Matcher object
    ClassVisitorParser->>Matcher: Find Javadoc comment in code
    alt Javadoc comment found
        Matcher->>String: Extract Javadoc comment
        Matcher->>int: Get ending position of Javadoc comment
        Matcher->>String: Extract method code
        Matcher->>String[]: Return Javadoc comment and method code
    else Javadoc comment not found
        Matcher->>String[]: Return empty Javadoc comment and original code
```
