----
# ORIGINAL RESPONSE 
# Participants

- MermaidUtils
- ContentRule
- Result
- RuleResult

# Initial Interactions

1. Create new `ContentRule`.
2. Call the `createRule()` method of `MermaidUtils` class and assign the returned value to the `ContentRule` variable.
3. Invoke the `validate()` method with the `content` parameter.
4. Check if the `result` of `validate` equals 0 and `exception` is null.
5. If the condition is true, return `RuleResult.SUCCESS`.
6. If the condition is false, split the `errors` string and store it in the `errorParts` array.
7. Check if the length of `errorParts` is greater than 1.
8. If the condition is true, assign `errorParts[0]` to `errors`, otherwise assign the original `validate.getErrors()` to `errors`.
9. Print `content` and three new lines.
10. Build and return a new `RuleResult` object with the description, lineNumber, violatedLine, and ruleName as specified.

# Clean Interactions

- Create new `ContentRule`                                : MermaidUtils -> ContentRule
- Call `createRule()` method                              : MermaidUtils -> RuleResult
- Invoke `validate()` method with `content` parameter      : RuleResult -> Result
- Check if `result` equals 0 and `exception` is null        : Result -> RuleResult
- If condition is true, return `RuleResult.SUCCESS`        : RuleResult --> RuleResult
- If condition is false, split `errors` string             : RuleResult --> RuleResult
- Check if `errorParts` length is greater than 1           : RuleResult --> RuleResult
- If condition is true, assign `errorParts[0]` to `errors` : RuleResult --> RuleResult
- Print `content` and three new lines                      : RuleResult -> RuleResult
- Build and return new `RuleResult` object                 : RuleResult --> RuleResult

# Final Participants

- MermaidUtils
  - Clean Interactions: create new `ContentRule`, call `createRule()` method

- ContentRule
  - Clean Interactions: none
  - Marked to be removed

- Result
  - Clean Interactions: invoke `validate()` method

- RuleResult
  - Clean Interactions: return `RuleResult.SUCCESS`, assign `errorParts[0]` to `errors`, build and return new `RuleResult` object


```java
---
title: Create Content Rule
---

sequenceDiagram
    participant MermaidUtils #B3DF85
    participant ContentRule #FFD700
    participant Result #4169E1
    participant RuleResult #7CFC00

    MermaidUtils->>ContentRule: Create new ContentRule
    MermaidUtils->>RuleResult: Call createRule()
    RuleResult->>Result: Invoke validate(content)
    Result-->>RuleResult: Get result and exception
    alt Valid content
        RuleResult-->>RuleResult: Return RuleResult.SUCCESS
    else Invalid content
        RuleResult-->>RuleResult: Split errors
        alt Multiple error parts
            RuleResult-->>RuleResult: Assign errorParts[0] to errors
        else Single error part
            RuleResult-->>RuleResult: Assign original validate.getErrors() to errors
        end
        RuleResult-->>RuleResult: Print content and three new lines
        RuleResult-->>RuleResult: Build and return RuleResult object
    end
```

End of instructions.