----
# ORIGINAL RESPONSE 
# Participants

- NoPrimitiveOrBasicTypesRule
- RuleResult
- Pattern
- Relationship

# Initial Interactions

- NoPrimitiveOrBasicTypesRule -> Constructor: Create NoPrimitiveOrBasicTypesRule object
- NoPrimitiveOrBasicTypesRule -> Pattern: Compile regex pattern
- NoPrimitiveOrBasicTypesRule -> System.out: Print message "NOT VALID " + line

# Clean Interactions

```mermaid
NoPrimitiveOrBasicTypesRule ->> System.out: Print message "NOT VALID " + line
```

# Final Participants

- NoPrimitiveOrBasicTypesRule
    - NoPrimitiveOrBasicTypesRule -> System.out
    
# Plain English Title

Check (com.cloudurable.docgen.mermaid.validation.classes.NoPrimitiveOrBasicTypesRule)

# Mermaid Sequence Diagram

```mermaid
---
title: Check (com.cloudurable.docgen.mermaid.validation.classes.NoPrimitiveOrBasicTypesRule)
---

sequenceDiagram
    participant NoPrimitiveOrBasicTypesRule
    participant System.out
    
    NoPrimitiveOrBasicTypesRule->>System.out: Print message "NOT VALID " + line
```
