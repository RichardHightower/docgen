----
# FIX RAW RESPONSE 2
# Participants After Fix
1. NoPrimitiveOrBasicTypesRule
2. System.out

# Interaction After Fix
1. NoPrimitiveOrBasicTypesRule->>System.out: Print message "NOT VALID " + line

# Final Participants
1. NoPrimitiveOrBasicTypesRule

# Plain English Title
NoPrimitiveOrBasicTypesRule Validation

# Mermaid Sequence Diagram
```mermaid
---
title: NoPrimitiveOrBasicTypesRule Validation
---

sequenceDiagram
    participant NoPrimitiveOrBasicTypesRule
    participant System.out

    NoPrimitiveOrBasicTypesRule->>System.out: Print message "NOT VALID " + line
```
