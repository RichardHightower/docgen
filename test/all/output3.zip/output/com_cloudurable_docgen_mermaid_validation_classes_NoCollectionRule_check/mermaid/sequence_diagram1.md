----
# ORIGINAL RESPONSE 
# Participants

- NoCollectionRule
- Pattern
- Relationship
- RuleResult

# Initial Interactions

- NoCollectionRule checks if the line contains a relationship.
- If the line contains a relationship, parse the relationship.
- If the relationship is not found, print "NOT VALID" and return RuleResult with a description of "Not a valid relationship".
- Check the left class of the relationship.
- If the check for the left class is successful, check the right class of the relationship.
- If the check for the left class is not successful, return the result of the left check.
- If the line does not contain a relationship, return RuleResult.SUCCESS.

# Clean Interactions

- NoCollectionRule->>Relationship: check if line contains a relationship
- alt Relationship is not found
  - NoCollectionRule->>System.out: Print "NOT VALID"
  - NoCollectionRule->>RuleResult: Return RuleResult with description "Not a valid relationship"
  - end
- alt Relationship is found
  - NoCollectionRule->>Relationship: Parse relationship
  - NoCollectionRule->>NoCollectionRule: Check left class of relationship
  - alt Left class check is successful
    - NoCollectionRule->>NoCollectionRule: Check right class of relationship
    - NoCollectionRule->>RuleResult: Return RuleResult
  - else Left class check is not successful
    - NoCollectionRule->>RuleResult: Return result of left class check
  - end
- else Line does not contain a relationship
  - NoCollectionRule->>RuleResult: Return RuleResult.SUCCESS
- end


# Final Participants

- NoCollectionRule
  - alt
  - else
  - end
- Pattern
  - alt
  - else
  - end
- Relationship
  - NoCollectionRule
  - alt
  - else
  - end
- RuleResult
  - NoCollectionRule
  - NoCollectionRule

# Plain English Title

Checking No Collection Rule

# Mermaid Sequence Diagram

```mermaid
---
title: Checking No Collection Rule
---

sequenceDiagram
    participant NoCollectionRule
    participant Relationship
    participant System.out
    participant RuleResult

    NoCollectionRule->>Relationship: check if line contains a relationship
    alt Relationship is not found
        NoCollectionRule->>System.out: Print "NOT VALID"
        NoCollectionRule->>RuleResult: Return RuleResult
    else Relationship is found
        NoCollectionRule->>Relationship: Parse relationship
        NoCollectionRule->>NoCollectionRule: Check left class of relationship
        alt Left class check is successful
            NoCollectionRule->>NoCollectionRule: Check right class of relationship
            NoCollectionRule->>RuleResult: Return RuleResult
        else Left class check is not successful
            NoCollectionRule->>RuleResult: Return result of left class check
        end
    else Line does not contain a relationship
        NoCollectionRule->>RuleResult: Return RuleResult.SUCCESS
    end
```
