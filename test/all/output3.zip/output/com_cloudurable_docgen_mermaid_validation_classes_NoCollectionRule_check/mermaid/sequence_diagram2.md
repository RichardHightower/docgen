----
# FIX RAW RESPONSE 3
# Validation Fixes
1. Replace `System.out` participant with a more appropriate participant.
2. Remove the `System.out` interaction.

# Participants After Fix
1. NoCollectionRule
2. Relationship
3. RuleResult

# Interaction After Fix
1. NoCollectionRule->>Relationship: Check if line contains a relationship.
2. alt Relationship is not found
   - NoCollectionRule->>RuleResult: Return RuleResult.
3. else Relationship is found
   - NoCollectionRule->>Relationship: Parse relationship.
   - NoCollectionRule->>NoCollectionRule: Check left class of relationship.
   - alt Left class check is successful
     - NoCollectionRule->>NoCollectionRule: Check right class of relationship.
     - NoCollectionRule->>RuleResult: Return RuleResult.
   - else Left class check is not successful
     - NoCollectionRule->>RuleResult: Return result of left class check.
   - end
4. else Line does not contain a relationship
   - NoCollectionRule->>RuleResult: Return RuleResult.SUCCESS.

# Final Participants
1. NoCollectionRule
2. Relationship
3. RuleResult

# Plain English Title
Checking No Collection Rule

# Mermaid Sequence Diagram

```mermaid
---
title: Checking No Collection Rule
---

sequenceDiagram
    participant NoCollectionRule
    participant Relationship
    participant RuleResult

    NoCollectionRule->>Relationship: Check if line contains a relationship
    alt Relationship is not found
        NoCollectionRule->>RuleResult: Return RuleResult
    else Relationship is found
        NoCollectionRule->>Relationship: Parse relationship
        NoCollectionRule->>NoCollectionRule: Check left class of relationship
        alt Left class check is successful
            NoCollectionRule->>NoCollectionRule: Check right class of relationship
            NoCollectionRule->>RuleResult: Return RuleResult
        else Left class check is not successful
            NoCollectionRule->>RuleResult: Return result of left class check
        end
    else Line does not contain a relationship
        NoCollectionRule->>RuleResult: Return RuleResult.SUCCESS
    end
```
