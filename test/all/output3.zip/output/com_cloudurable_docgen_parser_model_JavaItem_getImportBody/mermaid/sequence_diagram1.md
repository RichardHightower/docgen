----
# ORIGINAL RESPONSE 
# Participants

- JavaItem
- JavaItemType

# Initial Interactions

JavaItem.getImportBody() -> getImportBody

# Clean Interactions

getImportBody -> JavaItem: get the import body

# Final Participants

- JavaItem

    - getImportBody

# Plain English Title

JavaItem.getImportBody

# Mermaid Sequence Diagram

```mermaid
---
title: JavaItem.getImportBody
---

sequenceDiagram
    participant JavaItem

    JavaItem->>JavaItem: get the import body
```

End of instructions.