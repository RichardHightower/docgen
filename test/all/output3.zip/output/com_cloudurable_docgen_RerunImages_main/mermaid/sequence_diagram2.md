----
# FIX RAW RESPONSE 3
# Participants

1. RerunImages
2. File
3. System

# Validation Fixes
- Line 6: Replace "File" with a more actionable participant like "FileHandler"
- Line 9: Replace "File" with a more actionable participant like "FileHandler"
- Line 10: Replace "File" with a more actionable participant like "FileHandler"

# Interaction After Fix

- RerunImages creates a new FileHandler object called `outputDir`.
- RerunImages checks if `outputDir` exists.
  - If `outputDir` does not exist, the program exits.
  - If `outputDir` exists, RerunImages calls the `runImageGenCheck` method.

# Final Participants

- RerunImages
- FileHandler
- System

# Plain English Title

Main Execution of RerunImages Class

# Mermaid Sequence Diagram

```mermaid
---
title: Main Execution of RerunImages Class
---

sequenceDiagram
    participant RerunImages
    participant FileHandler
    participant System

    RerunImages->>FileHandler: Create new FileHandler object `outputDir`
    RerunImages->>FileHandler: Check if `outputDir` exists
    alt `outputDir` does not exist
        RerunImages->>System: Exit program
    else `outputDir` exists
        RerunImages->>RerunImages: Call runImageGenCheck
    end
```

End of instructions.