----
# ORIGINAL RESPONSE 
# Participants

- RerunImages
- File
- Exception
- System

# Initial Interactions

- RerunImages creates a new File object called `outputDir` using the provided command line arguments or a default value.
- RerunImages checks if `outputDir` exists.
- If `outputDir` does not exist, the program exits.
- If `outputDir` exists, RerunImages calls the `runImageGenCheck` method.

# Clean Interactions

- RerunImages creates a new File object called `outputDir` using the provided command line arguments or a default value.
- RerunImages checks if `outputDir` exists.
	- alt `outputDir` does not exist
		- RerunImages exits the program.
	- else `outputDir` exists
		- RerunImages calls the `runImageGenCheck` method.

# Final Participants

- RerunImages
	- Interactions: 
		- "RerunImages creates a new File object called `outputDir` using the provided command line arguments or a default value."
		- "RerunImages checks if `outputDir` exists."
		- "If `outputDir` does not exist, the program exits."
		- "If `outputDir` exists, RerunImages calls the `runImageGenCheck` method."
- File
	- Interactions: 
		- "RerunImages creates a new File object called `outputDir` using the provided command line arguments or a default value."
		- "RerunImages checks if `outputDir` exists."
- Exception
	- Interactions: None
- System
	- Interactions: None

# Plain English Title

Main Execution of RerunImages Class

# Mermaid Sequence Diagram

```mermaid
---
title: Main Execution of RerunImages Class
---

sequenceDiagram
    participant RerunImages
    participant File
    participant System

    RerunImages->>File: Create new File object `outputDir`
    RerunImages->>File: Check if `outputDir` exists
    alt `outputDir` does not exist
        RerunImages->>System: Exit program
    else `outputDir` exists
        RerunImages->>RerunImages: Call runImageGenCheck
    end
```

