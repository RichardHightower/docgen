----
# ORIGINAL RESPONSE 
# Participants

- NoArrayRule
- Pattern
- Matcher
- RuleResult

# Initial Interactions

No interaction described yet.

# Clean Interactions

1. NoArrayRule->>Pattern: Compile regex pattern
2. NoArrayRule->>Matcher: Match regex pattern
3. alt Match found
    4. NoArrayRule-->>Matcher: Get array declaration
    5. NoArrayRule-->>Matcher: Get class name
    alt Side is "Right"
        6. NoArrayRule-->>NoArrayRule: Create description for "Right" side
    else Side is NOT "Right"
        7. NoArrayRule-->>NoArrayRule: Create description for NOT "Right" side
    end
    8. NoArrayRule-->>RuleResult: Construct RuleResult with line information and description
else No match found
    9. NoArrayRule-->>RuleResult: Construct SUCCESS RuleResult
end

# Final Participants

- NoArrayRule
  - NoArrayRule->>Pattern: Compile regex pattern
  - NoArrayRule->>Matcher: Match regex pattern
  - NoArrayRule-->>Matcher: Get array declaration
  - NoArrayRule-->>Matcher: Get class name
  - NoArrayRule-->>NoArrayRule: Create description for "Right" side
  - NoArrayRule-->>NoArrayRule: Create description for NOT "Right" side
  - NoArrayRule-->>RuleResult: Construct RuleResult with line information and description
  - NoArrayRule-->>RuleResult: Construct SUCCESS RuleResult
- Pattern
- Matcher
- RuleResult

# Plain English Title

checkForArray (com.cloudurable.docgen.mermaid.validation.classes.NoArrayRule)

# Mermaid Sequence Diagram

```mermaid
---
title: checkForArray (com.cloudurable.docgen.mermaid.validation.classes.NoArrayRule)
---

sequenceDiagram
    participant NoArrayRule
    participant Pattern
    participant Matcher
    participant RuleResult

    NoArrayRule->>Pattern: Compile regex pattern
    NoArrayRule->>Matcher: Match regex pattern
    NoArrayRule-->>Matcher: Get array declaration
    NoArrayRule-->>Matcher: Get class name
    alt Match found
        NoArrayRule-->>NoArrayRule: Create description for "Right" side
    else No match found
        NoArrayRule-->>RuleResult: Construct SUCCESS RuleResult
    end
    NoArrayRule-->>RuleResult: Construct RuleResult with line information and description
```
