----
# FIX RAW RESPONSE 2
# Participants

- RuleRunner
- List
- RuleResult
- JsonBuilder
- PrettyJsonSerializer

# Validation Fixes

- Fix the issue with the loop without a corresponding end at line 17.
- Fix the issue with the description that contains multiple lines in the MermaidImageGen rule at line 0.

# Interaction After Fix

1. RuleRunner creates a JsonBuilder instance.
2. JsonBuilder starts an array.
3. RuleRunner iterates over each RuleResult in ruleResults.
4. JsonBuilder starts a nested object element.
5. JsonBuilder adds attributes (lineNumber, violatedLine, ruleName, description) based on RuleResult.
6. JsonBuilder ends the nested object element.
7. JsonBuilder ends the array.
8. JsonBuilder converts the JSON to a string.

# Final Participants

- RuleRunner
- JsonBuilder

# Plain English Title

Serialize Rule Results

# Mermaid Sequence Diagram

```mermaid
---
title: Serialize Rule Results
---

sequenceDiagram
    participant RuleRunner
    participant JsonBuilder

    RuleRunner->>JsonBuilder: Start Array
    loop for each RuleResult in ruleResults
        RuleRunner->>JsonBuilder: Start Nested Object Element
        RuleRunner->>JsonBuilder: Add Attribute lineNumber
        RuleRunner->>JsonBuilder: Add Attribute violatedLine
        RuleRunner->>JsonBuilder: Add Attribute ruleName
        RuleRunner->>JsonBuilder: Add Attribute description
        RuleRunner->>JsonBuilder: End Nested Object Element
    end
    RuleRunner->>JsonBuilder: End Array
    RuleRunner->>JsonBuilder: Convert to String
```

End of instructions.