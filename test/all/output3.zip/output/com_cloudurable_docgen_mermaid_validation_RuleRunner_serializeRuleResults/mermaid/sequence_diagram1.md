----
# ORIGINAL RESPONSE 
# Participants

- RuleRunner
- JsonBuilder
- LineRule
- ContentRule
- RuleResult

# Initial Interactions

- RuleRunner calls `serializeRuleResults` with `ruleResults` parameter

# Clean Interactions

- RuleRunner->JsonBuilder: Start Array
- loop for each `RuleResult` in `ruleResults`
  - RuleRunner->JsonBuilder: Start Nested Object Element
  - RuleRunner->JsonBuilder: Add Attribute "lineNumber" with ruleResult.getLineNumber()
  - RuleRunner->JsonBuilder: Add Attribute "violatedLine" with ruleResult.getViolatedLine()
  - RuleRunner->JsonBuilder: Add Attribute "ruleName" with ruleResult.getRuleName()
  - RuleRunner->JsonBuilder: Add Attribute "description" with ruleResult.getDescription()
  - RuleRunner->JsonBuilder: End Object
- RuleRunner->JsonBuilder: End Array
- RuleRunner->JsonBuilder: Convert to String

# Final Participants

- RuleRunner
  - RuleRunner->JsonBuilder: Start Array
  - loop for each `RuleResult` in `ruleResults`
    - RuleRunner->JsonBuilder: Start Nested Object Element
    - RuleRunner->JsonBuilder: Add Attribute "lineNumber" with ruleResult.getLineNumber()
    - RuleRunner->JsonBuilder: Add Attribute "violatedLine" with ruleResult.getViolatedLine()
    - RuleRunner->JsonBuilder: Add Attribute "ruleName" with ruleResult.getRuleName()
    - RuleRunner->JsonBuilder: Add Attribute "description" with ruleResult.getDescription()
    - RuleRunner->JsonBuilder: End Object
  - RuleRunner->JsonBuilder: End Array
  - RuleRunner->JsonBuilder: Convert to String
- JsonBuilder
  - RuleRunner->JsonBuilder: Start Array
  - loop for each `RuleResult` in `ruleResults`
    - RuleRunner->JsonBuilder: Start Nested Object Element
    - RuleRunner->JsonBuilder: Add Attribute "lineNumber" with ruleResult.getLineNumber()
    - RuleRunner->JsonBuilder: Add Attribute "violatedLine" with ruleResult.getViolatedLine()
    - RuleRunner->JsonBuilder: Add Attribute "ruleName" with ruleResult.getRuleName()
    - RuleRunner->JsonBuilder: Add Attribute "description" with ruleResult.getDescription()
    - RuleRunner->JsonBuilder: End Object

# Plain English Title

Serialize Rule Results

# Mermaid Sequence Diagram

```mermaid
---
title: Serialize Rule Results
---

sequenceDiagram
    participant RuleRunner
    participant JsonBuilder

    RuleRunner->JsonBuilder: Start Array
    loop for each RuleResult in ruleResults
        RuleRunner->JsonBuilder: Start Nested Object Element
        RuleRunner->JsonBuilder: Add Attribute lineNumber
        RuleRunner->JsonBuilder: Add Attribute violatedLine
        RuleRunner->JsonBuilder: Add Attribute ruleName
        RuleRunner->JsonBuilder: Add Attribute description
        RuleRunner->JsonBuilder: End Object
    RuleRunner->JsonBuilder: End Array
    RuleRunner->JsonBuilder: Convert to String
```

End of instructions.