----
# FIX RAW RESPONSE 3
# Fix Prompt Try 3

# Participants
- RuleRunner
- JsonBuilder
- RuleResult

# Validation Fixes
- RuleRunner is not a valid participant because it has no substantial actions or significant interactions. Remove RuleRunner from the participants list.

# Interaction After Fix
- The RuleResult does not interact with any participants. Remove RuleResult from the interaction sequence.

# Final Participants
- JsonBuilder

# Plain English Title
Serialize Rule Results

# Mermaid Sequence Diagram
```mermaid
---
title: Serialize Rule Results
---

sequenceDiagram
    participant JsonBuilder

    JsonBuilder->JsonBuilder: Start Array
    loop for each RuleResult in ruleResults
        JsonBuilder->JsonBuilder: Start Nested Object Element
        JsonBuilder->JsonBuilder: Add Attribute lineNumber
        JsonBuilder->JsonBuilder: Add Attribute violatedLine
        JsonBuilder->JsonBuilder: Add Attribute ruleName
        JsonBuilder->JsonBuilder: Add Attribute description
        JsonBuilder->JsonBuilder: End Nested Object Element
    JsonBuilder->JsonBuilder: End Array
    JsonBuilder->JsonBuilder: Convert to String
```
End of instructions.