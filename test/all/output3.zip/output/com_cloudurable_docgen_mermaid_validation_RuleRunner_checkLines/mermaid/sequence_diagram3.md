----
# FIX RAW RESPONSE 2
# Participants After Fix
- RuleRunner
- ArrayList
- LineRule
- RuleResult

# Validation Fixes
- Remove the participant "String" as it is not a valid participant according to the guidelines.

# Interaction After Fix

***Interaction: Create results list***
- RuleRunner creates an instance of ArrayList to hold the results list.

***Loop: For each line in lines***
- For each line in the given lines:
  - RuleRunner retrieves the content of the line.
  - RuleRunner runs the line rule.
  - LineRule returns the line rule results.
  - RuleRunner adds the line rule results to the results list.

***Interaction: Return results list***
- RuleRunner returns the results list after processing all the lines.

# Final Participants
- RuleRunner
- ArrayList
- LineRule
- RuleResult

# Plain English Title
Check Lines

# Mermaid Sequence Diagram

```mermaid
---
title: Check Lines
---

sequenceDiagram
    participant RuleRunner
    participant ArrayList
    participant LineRule
    participant RuleResult
    
    RuleRunner->>ArrayList: Create results list
    loop For each line in lines
        RuleRunner->>RuleRunner: Retrieve line content
        RuleRunner->>LineRule: Run line rule
        LineRule-->>RuleRunner: Return line rule results
        RuleRunner->>ArrayList: Add line rule results to results list
    end
    RuleRunner->>ArrayList: Return results list
```
