----
# ORIGINAL RESPONSE 
# Participants

- RuleRunner
- List<String>
- ArrayList
- LineRule
- ContentRule
- RuleResult

# Initial Interactions

1. RuleRunner receives a `List` of `String` lines to check.
2. RuleRunner initializes an empty `ArrayList` called `results` to store the rule results.
3. RuleRunner iterates over each line in the input `List`.
4. For each line, RuleRunner retrieves the line content.
5. RuleRunner calls the `runLineRule` method with the line index and content to get a list of `RuleResult`.
6. RuleRunner adds all the `RuleResult` objects to the `results` list.
7. RuleRunner returns the `results` list.

# Clean Interactions

1. RuleRunner->>List: checkLines(lines)
2. RuleRunner->>ArrayList: Create results list
3. loop For each line in lines
    - RuleRunner->>List: Retrieve line content
    - RuleRunner->>LineRule: Run line rule
    - LineRule-->>RuleRunner: Return line rule results
    - RuleRunner->>ArrayList: Add line rule results to results list
4. RuleRunner->>ArrayList: Return results list

# Final Participants

- RuleRunner
  - checkLines
- List
  - checkLines
- ArrayList
  - Create results list
  - Add line rule results to results list
  - Return results list
- LineRule
  - Run line rule
- RuleResult

# Plain English Title

Check Lines

# Mermaid Sequence Diagram

```mermaid
---
title: Check Lines
---

sequenceDiagram
    RuleRunner->>List: checkLines(lines)
    RuleRunner->>ArrayList: Create results list
    loop For each line in lines
        RuleRunner->>List: Retrieve line content
        RuleRunner->>LineRule: Run line rule
        LineRule-->>RuleRunner: Return line rule results
        RuleRunner->>ArrayList: Add line rule results to results list
    end
    RuleRunner->>ArrayList: Return results list
```

