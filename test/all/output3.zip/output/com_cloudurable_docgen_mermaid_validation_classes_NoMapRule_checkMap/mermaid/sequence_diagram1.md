----
# ORIGINAL RESPONSE 
# Participants

* NoMapRule
* Pattern
* Matcher
* RuleResult

# Initial Interactions

1. NoMapRule class has a private field PATTERN of type Pattern.
2. NoMapRule class has the checkMap() method that takes in side, input, line, and lineNumber parameters.
3. checkMap() method creates an instance of Matcher and sets it to the result of calling matcher() on the PATTERN field.
4. checkMap() method calls find() on the matcher object.
5. If the find() method returns true, the method returns an instance of RuleResult with ruleName, lineNumber, violatedLine, and description fields set according to the condition inside the if statement. Otherwise, it returns a RuleResult instance with the SUCCESS status.

# Clean Interactions

1. NoMapRule->>Pattern: Create an instance of Pattern
2. NoMapRule->>Matcher: Call matcher() with input on the created Pattern instance
3. Matcher-->>NoMapRule: Return an instance of Matcher
4. NoMapRule->>Matcher: Call find() on the created Matcher instance
5. alt Result of find() is true
    6. NoMapRule->>RuleResult: Create an instance of RuleResult
    7. RuleResult-->>NoMapRule: Return an instance of RuleResult
    8. Note right of NoMapRule: Set ruleName, lineNumber, violatedLine and description fields
    9. NoMapRule->>Console: Print success message
10. else Result of find() is false
    11. NoMapRule->>Console: Print failure message
12. end

# Final Participants

* NoMapRule
  * alt
  * else
  * RuleResult

# Plain English Title

No Map Rule

# Mermaid Sequence Diagram

```mermaid
---
title: No Map Rule
---

sequenceDiagram
    participant NoMapRule
    participant Pattern
    participant Matcher
    participant RuleResult

    NoMapRule->>Pattern: Create an instance of Pattern
    NoMapRule->>Matcher: Call matcher() with input on Pattern instance
    Matcher-->>NoMapRule: Return an instance of Matcher
    NoMapRule->>Matcher: Call find() on Matcher instance
    alt Result of find() is true
        NoMapRule->>RuleResult: Create an instance of RuleResult
        RuleResult-->>NoMapRule: Return an instance of RuleResult
        NoMapRule->>Console: Print success message
    else Result of find() is false
        NoMapRule->>Console: Print failure message
    end
```

End of instructions.