----
# ORIGINAL RESPONSE 
# Participants

- NoMapRule
- Pattern
- System.out
- Relationship
- RuleResult

# Initial Interactions

- NoMapRule -> Pattern: Compile regex pattern
- NoMapRule -> System.out: Print line rule violation
  
# Clean Interactions

- NoMapRule -> Pattern: Compile regex pattern
- NoMapRule -> System.out: Print line rule violation message
  
# Final Participants

- NoMapRule
  - NoMapRule -> Pattern
  - NoMapRule -> System.out
  
- Pattern
  - NoMapRule -> Pattern
  
- System.out
  - NoMapRule -> System.out
  
- Relationship
- RuleResult

# Plain English Title

Check NoMapRule

# Mermaid Sequence Diagram

```mermaid
---
title: Check NoMapRule
---

sequenceDiagram
    participant NoMapRule
    participant Pattern
    participant System.out
    
    NoMapRule->>Pattern: Compile regex pattern
    NoMapRule->>System.out: Print line rule violation message
```

End of instructions.