----
# ORIGINAL RESPONSE 
# Participants

- LineRule

# Initial Interactions

- LineRule checks a given line for a rule violation.
- LineRule has a `check` method that takes a line and line number as input.
- The `check` method returns a RuleResult after performing the rule check.

# Clean Interactions

```plaintext
LineRule-->>RuleResult: Check if line violates rule
```

# Final Participants

- LineRule
  - LineRule checks a given line for a rule violation.

# Plain English Title

Check Line Rule

# Mermaid Sequence Diagram

```mermaid
---
title: Check Line Rule
---

sequenceDiagram
    participant LineRule
    participant RuleResult

    LineRule-->>RuleResult: Check if line violates rule
```

End of instructions.