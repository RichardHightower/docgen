----
# ORIGINAL RESPONSE 
# Participants

- RuleRunner
- LineRule
- ContentRule
- List
- String
- ArrayList
- RuleResult

# Initial Interactions

- RuleRunner calls `checkContent` method with `content` parameter.
- `content` is split into lines using the newline character as the delimiter.
- The lines are stored in the `lines` list.
- An empty `ruleResults` list is created to store the rule results.
- The `checkLines` method is called with the `lines` list, and the results are added to `ruleResults`.
- The `runContentRule` method is called with the `content` parameter, and the results are added to `ruleResults`.
- The `ruleResults` list is returned.

# Clean Interactions

```markdown
RuleRunner->>List: Split content to lines
 RuleRunner->>ArrayList: Create ruleResults list
 RuleRunner->>ArrayList: Add checkLines results to ruleResults
 RuleRunner->>ArrayList: Add runContentRule results to ruleResults
 RuleRunner-->>ArrayList: Return ruleResults
```

# Final Participants

- RuleRunner
    - Split content to lines
    - Create ruleResults list
    - Add checkLines results to ruleResults
    - Add runContentRule results to ruleResults
    - Return ruleResults
- List
- ArrayList

# Plain English Title

Check Content

# Mermaid Sequence Diagram

```mermaid
---
title: Check Content
---

sequenceDiagram
    participant RuleRunner
    participant ArrayList
    participant List

    RuleRunner->>List: Split content to lines
    RuleRunner->>ArrayList: Create ruleResults list
    RuleRunner->>ArrayList: Add checkLines results to ruleResults
    RuleRunner->>ArrayList: Add runContentRule results to ruleResults
    RuleRunner-->>ArrayList: Return ruleResults
```

End of instructions.