----
# ORIGINAL RESPONSE 
# Participants

- RuleRunner
- List
- LineRule
- ContentRule
- String
- ArrayList
- RuleResult

# Initial Interactions

- RuleRunner creates an empty List of LineRule and ContentRule.
- RuleRunner runs the `runLineRule` method with an integer `i` and a String `line`.
- Loop through each LineRule in the List of LineRules.
- For each LineRule, call the `check` method passing the current line and integer.
- If the result of the `check` method is not "SUCCESS", add the result to the results List.
- Return the results List.

# Clean Interactions

- RuleRunner->>List: Create empty List of LineRule and ContentRule
- RuleRunner->>rule: Call check method for each LineRule
- rule-->>LineRule: check line and integer
- LineRule-->>RuleRunner: Return RuleResult
- RuleRunner-->>List: Add non-SUCCESS results to List
- RuleRunner->>List: Return results

# Final Participants

- RuleRunner
  - Run LineRule
- List
  - Create empty List
  - Add non-SUCCESS results to List
  - Return results
- LineRule
  - Check line and integer
  - Return RuleResult
- ContentRule
- String
- ArrayList
- RuleResult

# Plain English Title

Run Line Rule

# Mermaid Sequence Diagram

```mermaid
---
title: Run Line Rule
---

sequenceDiagram
    participant RuleRunner
    participant List
    participant LineRule

    RuleRunner->>List: Create empty List
    loop For each LineRule in List
        RuleRunner->>LineRule: Call check method
        LineRule-->>RuleRunner: Return RuleResult
        if RuleResult is not SUCCESS
            RuleRunner->>List: Add result to List
        end
    end
    RuleRunner->>List: Return results
```

End of instructions.