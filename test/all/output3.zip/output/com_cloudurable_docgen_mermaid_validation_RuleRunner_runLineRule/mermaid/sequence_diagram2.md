----
# FIX RAW RESPONSE 3
# Participants

- RuleRunner
- List
- LineRule

# Validation Fixes

- Line 17: The `end` tag is missing an opening tag. Add the respective opening tag before the `end` tag.

# Interaction After Fix

No changes required.

# Final Participants

- RuleRunner
- List
- LineRule

# Plain English Title

Run Line Rule

# Mermaid Sequence Diagram

```mermaid
---
title: Run Line Rule
---
sequenceDiagram
    participant RuleRunner
    participant List
    participant LineRule

    RuleRunner->>List: Create empty List
    loop For each LineRule in List
        RuleRunner->>LineRule: Call check method
        LineRule-->>RuleRunner: Return RuleResult
        if RuleResult is not SUCCESS
            RuleRunner->>List: Add result to List
        end
    end
    RuleRunner->>List: Return results
```

End of instructions.