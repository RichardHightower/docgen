----
# FIX RAW RESPONSE 2
# Validation Fixes

1. **Mismatched Tags**: Add the missing opening tag before the `else` statement and the missing closing tag after the `end` statement.

# Participants After Fix

1. RuleRunner
2. List
3. LineRule

# Interaction After Fix

```markdown
RuleRunner->>List: Create empty List
loop For each LineRule in List
    RuleRunner->>LineRule: Call check method
    LineRule-->>RuleRunner: Return RuleResult
    alt RuleResult is not SUCCESS
        RuleRunner->>List: Add result to List
    end
end
RuleRunner->>List: Return results
```

# Final Participants

1. RuleRunner
2. List
3. LineRule

# Plain English Title

Run Line Rule

# Mermaid Sequence Diagram

```mermaid
---
title: Run Line Rule
---
sequenceDiagram
    participant RuleRunner
    participant List
    participant LineRule

    RuleRunner->>List: Create empty List
    loop For each LineRule in List
        RuleRunner->>LineRule: Call check method
        LineRule-->>RuleRunner: Return RuleResult
        alt RuleResult is not SUCCESS
            RuleRunner->>List: Add result to List
        end
    end
    RuleRunner->>List: Return results
```
