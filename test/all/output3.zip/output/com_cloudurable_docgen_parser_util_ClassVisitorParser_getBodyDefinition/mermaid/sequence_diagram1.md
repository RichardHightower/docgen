----
# ORIGINAL RESPONSE 
# Participants

- ClassVisitorParser
- CompilationUnit
- Object
- JavaItem
- StringBuilder

# Initial Interactions

- ClassVisitorParser creates CompilationUnit
- CompilationUnit.toString() is called
- CompilationUnit.toString() splits the string by newline character
- lines.length > numLinesMax is checked
- If lines.length is greater than numLinesMax, a loop breaks at 200
- StringBuilder appends line and newline character
- StringBuilder.toString() returns the final string

# Clean Interactions

- ClassVisitorParser creates CompilationUnit
- CompilationUnit's toString() is called
- CompilationUnit's toString() splits the string by newline character
- If lines.length is greater than numLinesMax
  - Loop until count is less than 200
    - StringBuilder appends line and newline character
  - StringBuilder.toString() returns the final string
- If lines.length is less than or equal to numLinesMax, CompilationUnit's toString() returns the original string

# Final Participants

- ClassVisitorParser
  - CompilationUnit's toString()

- CompilationUnit
  - CompilationUnit's toString()

- StringBuilder
  - StringBuilder's append()
  - StringBuilder's toString()

# Plain English Title

getBodyDefinition in ClassVisitorParser

# Mermaid Sequence Diagram

```mermaid
---
title: getBodyDefinition in ClassVisitorParser
---

sequenceDiagram
    participant ClassVisitorParser
    participant CompilationUnit
    participant Object
    participant JavaItem
    participant StringBuilder

    ClassVisitorParser ->> CompilationUnit: Create CompilationUnit
    CompilationUnit -->> CompilationUnit: toString()
    CompilationUnit -->> Object: toString()
    Object -->> JavaItem: toString()
    JavaItem -->> StringBuilder: append()
    StringBuilder -->> StringBuilder: toString()
    JavaItem -->> CompilationUnit: toString()
    CompilationUnit -->> ClassVisitorParser: Return String
```
