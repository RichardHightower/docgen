----
# FIX RAW RESPONSE 3
# Participants After Fix

1. RuleRunner
2. Builder

# Validation Fixes

1. No Method Calls In Descriptions Rule: Replace "Builder-->>RuleRunner: Returns new instance" with "Builder returns a new instance".
2. Avoid Notes Rule: Remove the notes from the diagram.

# Interaction After Fix

1. RuleRunner ->> Builder: static builder() method
2. Builder returns a new instance

# Final Participants

1. RuleRunner
2. Builder

# Plain English Title

Rule Runner - Builder Class

# Mermaid Sequence Diagram

```mermaid
---
title: Rule Runner - Builder Class
---

sequenceDiagram
    participant RuleRunner
    participant Builder

    RuleRunner->>Builder: static builder() method
    Builder returns a new instance
```

End of instructions.