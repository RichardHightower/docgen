----
# ORIGINAL RESPONSE 
# Participants

- RuleRunner
- LineRule
- ContentRule
- Builder

# Initial Interactions

- RuleRunner is a parent class with lineRules and contentRules fields.
- The RuleRunner class has a static builder() method that returns a new Builder instance.

# Clean Interactions

- LineRule and ContentRule are subclasses of RuleRunner.
- Builder is a nested class within RuleRunner and has a build() method.

# Final Participants

- RuleRunner
  - LineRule
  - ContentRule
- Builder

# Plain English Title

Rule Runner - Builder Class

# Mermaid Sequence Diagram

```mermaid
---
title: Rule Runner - Builder Class
---

sequenceDiagram
    participant RuleRunner
    participant Builder

    RuleRunner->>Builder: static builder() method
    Note right of Builder: Builder is nested<br/>class within RuleRunner
    Builder-->>RuleRunner: Returns new instance
    Note left of Builder: Builder has a<br/>build() method
```

End of instructions.