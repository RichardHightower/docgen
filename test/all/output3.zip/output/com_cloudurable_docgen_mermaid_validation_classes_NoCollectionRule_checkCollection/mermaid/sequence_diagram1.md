----
# ORIGINAL RESPONSE 
# Participants

* NoCollectionRule
* Pattern
* Matcher
* RuleResult


# Initial Interactions

1. NoCollectionRule calls PATTERN.matcher(input)
2. NoCollectionRule finds a match
3. NoCollectionRule gets collectionType from the match
4. NoCollectionRule gets genericType from the match
5. NoCollectionRule gets description based on side and replaces input in the line
6. NoCollectionRule creates RuleResult with ruleName, lineNumber, violatedLine, and description


# Clean Interactions

1. NoCollectionRule->>Pattern: matcher()
2. NoCollectionRule-->>Matcher: match found
3. NoCollectionRule->>Matcher: group(1)
4. NoCollectionRule->>Matcher: group(2)
5. NoCollectionRule->>NoCollectionRule: get description based on side
6. NoCollectionRule->>NoCollectionRule: replace input in the line
7. NoCollectionRule->>NoCollectionRule: create RuleResult


# Final Participants

* NoCollectionRule
    * Initial Interactions
    * Clean Interactions
* Pattern
    * Initial Interactions
* Matcher
    * Initial Interactions
* RuleResult
    * Initial Interactions
    * Clean Interactions


# Plain English Title

`NoCollectionRule calls PATTERN.matcher(input) to check for collection in the line.`


# Mermaid Sequence Diagram

```mermaid
---
title: NoCollectionRule calls PATTERN.matcher()
---

sequenceDiagram
    participant NoCollectionRule
    participant Pattern
    participant Matcher
    participant RuleResult

    NoCollectionRule->>Pattern: matcher()
    NoCollectionRule-->>Matcher: match found
    NoCollectionRule->>Matcher: group(1)
    NoCollectionRule->>Matcher: group(2)
    NoCollectionRule->>NoCollectionRule: get description
    NoCollectionRule->>NoCollectionRule: replace input in the line
    NoCollectionRule->>NoCollectionRule: create RuleResult
```

End of instructions.