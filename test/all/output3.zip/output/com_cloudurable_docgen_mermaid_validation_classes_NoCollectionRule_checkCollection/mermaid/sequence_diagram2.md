----
# FIX RAW RESPONSE 3
# Participants

- NoCollectionRule (NoCollectionRule)
- Pattern (Pattern)
- Matcher (Matcher)
- RuleResult (RuleResult)

# Validation Fixes

- No method calls in descriptions
  - Description: Remove the method calls in the descriptions.

# Interaction After Fix

- NoCollectionRule->>Pattern: match found
- NoCollectionRule->>Matcher: group(1)
- NoCollectionRule->>Matcher: group(2)
- NoCollectionRule->>NoCollectionRule: get description
- NoCollectionRule->>NoCollectionRule: replace input in the line
- NoCollectionRule->>NoCollectionRule: create RuleResult

# Final Participants

- NoCollectionRule
- Pattern
- Matcher
- RuleResult

# Plain English Title

NoCollectionRule calls PATTERN matcher

# Mermaid Sequence Diagram

```mermaid
---
title: NoCollectionRule calls PATTERN matcher
---

sequenceDiagram
    participant NoCollectionRule
    participant Pattern
    participant Matcher
    participant RuleResult

    NoCollectionRule->>Pattern: match found
    NoCollectionRule->>Matcher: group(1)
    NoCollectionRule->>Matcher: group(2)
    NoCollectionRule->>NoCollectionRule: get description
    NoCollectionRule->>NoCollectionRule: replace input in the line
    NoCollectionRule->>NoCollectionRule: create RuleResult
```

End of instructions.