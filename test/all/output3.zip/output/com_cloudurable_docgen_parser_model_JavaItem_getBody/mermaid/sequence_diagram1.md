----
# ORIGINAL RESPONSE 
# Participants

- JavaItem
- MethodParser
- MethodBody

# Initial Interactions

- JavaItem `-->` MethodParser: Call MethodParser to parse method
- MethodParser `-->` MethodBody: Get method body from JavaItem
- MethodBody `-->` JavaItem: Return method body

# Clean Interactions

- JavaItem `-->` MethodParser: Parse method
  - alt Method has a body
    - MethodParser `-->` MethodBody: Get method body
  - else Method has no body
    - MethodParser `-->` JavaItem: Method has no body
  - end

# Final Participants

- JavaItem
  - JavaItem `-->` MethodParser
- MethodParser
  - MethodParser `-->` MethodBody
- MethodBody
  - MethodBody `-->` JavaItem

# Plain English Title

Parsing a Java Method Body

# Mermaid Sequence Diagram

```mermaid
---
title: Parsing a Java Method Body
---

sequenceDiagram
    participant JavaItem
    participant MethodParser
    participant MethodBody

    JavaItem ->> MethodParser: Parse method
    alt Method has a body
        MethodParser ->> MethodBody: Get method body
    else Method has no body
        MethodParser ->> JavaItem: Method has no body
    end
```

