----
# ORIGINAL RESPONSE 
# Participants

- RerunImages
- String

# Initial Interactions

- RerunImages calls the `removeExt` method and passes the `name` parameter.
- Inside the `removeExt` method, the `name` parameter is checked for the position of the "." character using the `indexOf` method.
- If the "." character is found at a position other than -1, the `substring` method is called on the `name` parameter to remove the extension and return the result.
- If the "." character is not found at any position, the `name` parameter is returned as is.
- The result of the `removeExt` method is captured and used within the program.

# Clean Interactions

RerunImages->>String: Call removeExt method\
alt "." character found at position i\
String->>RerunImages: Return substring of name\
else "." character not found\
String-->>RerunImages: Return name\
end\
RerunImages->>String: Capture result

# Final Participants

- RerunImages
   - Call removeExt method
   - Capture result
- String
   - Return substring of name
   - Return name

# Plain English Title

Remove File Extension

# Mermaid Sequence Diagram

```mermaid
---
title: Remove File Extension
---

sequenceDiagram
    participant RerunImages
    participant String
    RerunImages->>String: Call removeExt method
    alt "." character found at position i
        String->>RerunImages: Return substring of name
    else "." character not found
        String-->>RerunImages: Return name
    end
    RerunImages->>String: Capture result
```

