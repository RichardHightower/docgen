----
# FIX RAW RESPONSE 3
# Participants After Fix

1. NoArrayRule
2. LineRule
3. Pattern
4. Relationship
5. RuleResult

# Validation Fixes

1. No Method Calls In Descriptions Rule (Line 11)
   - Violated Line: `NoArrayRule-->Pattern: compile()`
   - Description: No method calls in descriptions. Instead of `NoArrayRule-->Pattern: compile()`, use `NoArrayRule-->Pattern: compile`.


2. No Method Calls In Descriptions Rule (Line 14)
   - Violated Line: `NoArrayRule-->>RuleResult: builder()`
   - Description: No method calls in descriptions. Instead of `NoArrayRule-->>RuleResult: builder()`, use `NoArrayRule-->>RuleResult: builder`.


3. No Method Calls In Descriptions Rule (Line 16)
   - Violated Line: `NoArrayRule-->>Relationship: parseRelationship()`
   - Description: No method calls in descriptions. Instead of `NoArrayRule-->>Relationship: parseRelationship()`, use `NoArrayRule-->>Relationship: parseRelationship`.


4. No Method Calls In Descriptions Rule (Line 18)
   - Violated Line: `NoArrayRule-->RuleResult: build()`
   - Description: No method calls in descriptions. Instead of `NoArrayRule-->RuleResult: build()`, use `NoArrayRule-->RuleResult: build`.


5. No Method Calls In Descriptions Rule (Line 23)
   - Violated Line: `NoArrayRule-->>Pattern: checkForArray()`
   - Description: No method calls in descriptions. Instead of `NoArrayRule-->>Pattern: checkForArray()`, use `NoArrayRule-->>Pattern: checkForArray`.


6. No Method Calls In Descriptions Rule (Line 27)
   - Violated Line: `NoArrayRule-->>Pattern: checkForArray()`
   - Description: No method calls in descriptions. Instead of `NoArrayRule-->>Pattern: checkForArray()`, use `NoArrayRule-->>Pattern: checkForArray`.


7. No Method Calls In Descriptions Rule (Line 31)
   - Violated Line: `NoArrayRule-->>Pattern: checkForArray()`
   - Description: No method calls in descriptions. Instead of `NoArrayRule-->>Pattern: checkForArray()`, use `NoArrayRule-->>Pattern: checkForArray`.


8. System Out Rule (Line 20)
   - Violated Line: `NoArrayRule-->>System.out: Print "NOT VALID"`
   - Description: Avoid using `System.out` in your mermaid code.


# Interaction After Fix

- NoArrayRule-->Pattern: compile
- NoArrayRule-->LineRule: "extends"
- RuleResult-->>NoArrayRule: SUCCESS
- NoArrayRule-->>RuleResult: builder
- NoArrayRule-->>Pattern: match input line
- NoArrayRule-->>Relationship: parseRelationship
- alt Relationship found
    - NoArrayRule-->RuleResult: build
    - alt Relationship is NOT_FOUND
        - NoArrayRule-->>System.out: Print "NOT VALID"
        - NoArrayRule-->>RuleResult: violatedLine
    - end
    - NoArrayRule-->>Pattern: checkForArray
    - NoArrayRule-->RuleResult: "SUCCESS"
    - RuleResult-->>NoArrayRule: leftCheck
    - alt leftCheck == RuleResult.SUCCESS
        - NoArrayRule-->>Pattern: checkForArray
    - else leftCheck != RuleResult.SUCCESS
        - NoArrayRule-->>RuleResult: leftCheck
    - end
    - NoArrayRule-->>Pattern: checkForArray
- else Relationship not found
    - NoArrayRule-->>RuleResult: SUCCESS
- end


# Final Participants

1. NoArrayRule
2. Pattern
3. LineRule
4. Relationship
5. RuleResult


# Plain English Title

Check (com.cloudurable.docgen.mermaid.validation.classes.NoArrayRule)


# Mermaid Sequence Diagram

```mermaid
---
title: Check (com.cloudurable.docgen.mermaid.validation.classes.NoArrayRule)
---

sequenceDiagram
    participant NoArrayRule
    participant Pattern
    participant LineRule
    participant Relationship
    participant RuleResult

    NoArrayRule-->Pattern: compile
    NoArrayRule-->LineRule: "extends"
    RuleResult-->>NoArrayRule: SUCCESS
    NoArrayRule-->>RuleResult: builder
    NoArrayRule-->>Pattern: match input line
    NoArrayRule-->>Relationship: parseRelationship
    alt Relationship found
        NoArrayRule-->RuleResult: build
        alt Relationship is NOT_FOUND
            NoArrayRule-->>System.out: Print "NOT VALID"
            NoArrayRule-->>RuleResult: violatedLine
        end
        NoArrayRule-->>Pattern: checkForArray
        NoArrayRule-->RuleResult: "SUCCESS"
        RuleResult-->>NoArrayRule: leftCheck
        alt leftCheck == RuleResult.SUCCESS
            NoArrayRule-->>Pattern: checkForArray
        else leftCheck != RuleResult.SUCCESS
            NoArrayRule-->>RuleResult: leftCheck
        end
        NoArrayRule-->>Pattern: checkForArray
    else Relationship not found
        NoArrayRule-->>RuleResult: SUCCESS
    end
```
