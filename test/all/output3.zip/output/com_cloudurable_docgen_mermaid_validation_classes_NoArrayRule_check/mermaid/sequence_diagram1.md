----
# ORIGINAL RESPONSE 
# Participants

1. NoArrayRule
2. Pattern
3. Relationship
4. RuleResult

# Initial Interactions

1. NoArrayRule `extends` LineRule
2. Private final Pattern PATTERN = Pattern.compile("([A-Za-z0-9_]+)\\s*\\[\\s*\\]");
   * Description: Define a regular expression pattern to match a specific format in the input string.
3. Method `check(String line, int lineNumber)`: Perform a rule check on the input line.
   * Description: This method checks if the input line contains a valid relationship. If it does, it further checks if the classes of the relationship are valid and not an array.
4. Check if Relationship exists in the input line.
   * Description: This step determines if the input line contains a relationship.
5. Parse Relationship from the input line.
   * Description: This step parses the relationship from the input line.
   * Alternative: If the relationship is not found, print "NOT VALID" with the input line and return RuleResult indicating a violation.
6. Check if the left class of the relationship is valid and not an array.
   * Description: This step checks if the left class of the relationship is a valid class and not an array.
7. Check if the right class of the relationship is valid and not an array.
   * Description: This step checks if the right class of the relationship is a valid class and not an array.
   * Alternative: If the left class check is successful, return the result of checking the right class.
   * Alternative: If the left class check fails, return the result of the left class check.
8. If there is no relationship in the input line, return RuleResult indicating a successful check.

# Clean Interactions

1. NoArrayRule `extends` LineRule
2. RuleResult.SUCCESS
   * Description: Indicates a successful rule check.
3. Pattern `compile` "([A-Za-z0-9_]+)\\s*\\[\\s*\\]"
   * Description: Compiles the regular expression pattern to match a specific format.
4. Relationship `parseRelationship` line
   * Description: Parses the relationship from the input line.
   * Alternative: If the relationship is not found, print "NOT VALID" with the input line and return RuleResult indicating a violation.
5. Check for relationship existence
   * Description: Checks if the input line contains a relationship.
6. Check the left class of the relationship for being an array
   * Description: Checks if the left class of the relationship is a valid class and not an array.
7. Check the right class of the relationship for being an array
   * Description: Checks if the right class of the relationship is a valid class and not an array.
8. Return RuleResult.SUCCESS indicating a successful rule check.

# Final Participants

- NoArrayRule
- Pattern
- Relationship
- RuleResult

# Plain English Title

Check (com.cloudurable.docgen.mermaid.validation.classes.NoArrayRule)

# Mermaid Sequence Diagram

```mermaid
---
title: Check (com.cloudurable.docgen.mermaid.validation.classes.NoArrayRule)
---

sequenceDiagram
    participant NoArrayRule
    participant LineRule
    participant Pattern
    participant Relationship
    participant RuleResult

    NoArrayRule-->Pattern: compile()
    NoArrayRule-->LineRule: "extends"
    RuleResult-->>NoArrayRule: SUCCESS
    NoArrayRule-->>RuleResult: builder()
    NoArrayRule-->>Pattern: match input line
    NoArrayRule-->>Relationship: parseRelationship()
    alt Relationship found
        NoArrayRule-->RuleResult: build()
        alt Relationship is NOT_FOUND
            NoArrayRule-->>System.out: Print "NOT VALID"
            NoArrayRule-->>RuleResult: violatedLine
        end
        NoArrayRule-->>Pattern: checkForArray()
        NoArrayRule-->RuleResult: "SUCCESS"
        RuleResult-->>NoArrayRule: leftCheck
        alt leftCheck == RuleResult.SUCCESS
            NoArrayRule-->>Pattern: checkForArray()
        else leftCheck != RuleResult.SUCCESS
            NoArrayRule-->>RuleResult: leftCheck
        end
        NoArrayRule-->>Pattern: checkForArray()
    else Relationship not found
        NoArrayRule-->>RuleResult: SUCCESS
    end
```

End of instructions.