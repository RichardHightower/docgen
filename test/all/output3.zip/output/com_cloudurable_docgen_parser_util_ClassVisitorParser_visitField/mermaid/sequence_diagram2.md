----
# FIX RAW RESPONSE 3
# Fix Prompts

## Validation Fixes
1. **No Method Calls In Descriptions Rule:** Replace method calls with plain English descriptions.
   - `ClassVisitorParser ->> FieldDeclaration: visitField(parent, field)` 
   - Fix: `ClassVisitorParser ->> FieldDeclaration: Visit Field`
2. **Mismatched Tags:** Add missing `end` tag after the `alt` block.
   - Fix: Add `end` after `JavaItem ->> List: Add JavaItem to javaItems List`
3. **MermaidImageGen:** Remove validation error message.

## Participants After Fix
1. ClassVisitorParser
2. FieldDeclaration
3. JavaItem
4. List

## Interaction After Fix
- ClassVisitorParser ->> FieldDeclaration: Visit Field
- alt extractJavaDoc returns valid javadoc and code
  - FieldDeclaration ->> ClassVisitorParser: Extracted Javadoc
  - FieldDeclaration ->> ClassVisitorParser: Extracted Code
  - ClassVisitorParser ->> JavaItem: Create JavaItem with Javadoc, Code, Parent, and Field Details
  - JavaItem ->> List: Add JavaItem to javaItems List
- else extractJavaDoc returns empty javadoc and code
  - ClassVisitorParser ->> JavaItem: Create JavaItem with Empty Javadoc, Code, Parent, and Field Details
  - JavaItem ->> List: Add JavaItem to javaItems List

## Plain English Title
Visit Field (ClassVisitorParser)

## Mermaid Sequence Diagram
```mermaid
---
title: Visit Field (ClassVisitorParser)
---

sequenceDiagram
    participant ClassVisitorParser
    participant FieldDeclaration
    participant JavaItem
    participant List

    ClassVisitorParser ->> FieldDeclaration: Visit Field
    alt extractJavaDoc returns valid javadoc and code
        FieldDeclaration ->> ClassVisitorParser: Extracted Javadoc
        FieldDeclaration ->> ClassVisitorParser: Extracted Code
        ClassVisitorParser ->> JavaItem: Create JavaItem with Javadoc, Code, Parent, and Field Details
        JavaItem ->> List: Add JavaItem to javaItems List
    else extractJavaDoc returns empty javadoc and code
        ClassVisitorParser ->> JavaItem: Create JavaItem with Empty Javadoc, Code, Parent, and Field Details
        JavaItem ->> List: Add JavaItem to javaItems List
```

End of instructions.