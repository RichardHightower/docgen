----
# ORIGINAL RESPONSE 
**Participants:**

- RerunImages
- MermaidUtils
- File

**Initial Interactions:**

- RerunImages calls `MermaidUtils.runMmdc(input, output)`.

**Clean Interactions:**

- RerunImages->>MermaidUtils: runMmdc

**Final Participants:**

- RerunImages
  - `MermaidUtils.runMmdc`

**Plain English Title:**

RerunImages Runs runMmdc

**Mermaid Sequence Diagram:**

```mermaid
---
title: RerunImages Runs runMmdc
---

sequenceDiagram
    participant RerunImages
    participant MermaidUtils

    RerunImages->>MermaidUtils: runMmdc
```