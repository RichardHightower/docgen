----
# FIX RAW RESPONSE 2
# Participants

- ClassVisitorParser
- ClassOrInterfaceDeclaration
- JavaItem

# Validation Fixes

- None

# Interaction After Fix

```markdown
ClassVisitorParser->>ClassOrInterfaceDeclaration: visitClass
ClassVisitorParser->>ClassOrInterfaceDeclaration: extractJavaDoc
ClassVisitorParser->>ClassOrInterfaceDeclaration: getBodyDefinition
ClassVisitorParser->>JavaItem: build JavaItem
ClassVisitorParser->>JavaItem: add to javaItems list
alt Is Interface
    ClassVisitorParser->>ClassOrInterfaceDeclaration: visitClassType
end
alt Is Class
    ClassVisitorParser->>ClassOrInterfaceDeclaration: visitClassType
    ClassVisitorParser->>ClassOrInterfaceDeclaration: visitMethod
end
ClassVisitorParser->>ClassOrInterfaceDeclaration: visitField
```

# Final Participants

- ClassVisitorParser
- ClassOrInterfaceDeclaration
- JavaItem

# Plain English Title

visitClass (com.cloudurable.docgen.parser.util.ClassVisitorParser)

# Mermaid Sequence Diagram

```mermaid
---
title: visitClass (com.cloudurable.docgen.parser.util.ClassVisitorParser)
---

sequenceDiagram
    participant ClassVisitorParser
    participant ClassOrInterfaceDeclaration
    participant JavaItem

    ClassVisitorParser->>ClassOrInterfaceDeclaration: visitClass
    ClassVisitorParser->>ClassOrInterfaceDeclaration: extractJavaDoc
    ClassVisitorParser->>ClassOrInterfaceDeclaration: getBodyDefinition
    ClassVisitorParser->>JavaItem: build JavaItem
    ClassVisitorParser->>JavaItem: add to javaItems list
    alt Is Interface
        ClassVisitorParser->>ClassOrInterfaceDeclaration: visitClassType
    end
    alt Is Class
        ClassVisitorParser->>ClassOrInterfaceDeclaration: visitClassType
        ClassVisitorParser->>ClassOrInterfaceDeclaration: visitMethod
    end
    ClassVisitorParser->>ClassOrInterfaceDeclaration: visitField
```

