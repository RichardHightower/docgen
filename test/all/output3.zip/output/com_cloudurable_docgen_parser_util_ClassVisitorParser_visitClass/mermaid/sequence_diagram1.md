----
# ORIGINAL RESPONSE 
# Participants

1. ClassVisitorParser
2. VoidVisitorAdapter
3. CompilationUnit
4. JavaItem
5. ClassOrInterfaceDeclaration

# Initial Interactions

1. **ClassVisitorParser** visits a class by invoking the `visitClass` method.
2. **ClassVisitorParser** extracts the **JavaDoc** and code from the class using the `extractJavaDoc` and `getBodyDefinition` methods.
3. **ClassVisitorParser** creates a **JavaItem** object with the extracted information.
4. **ClassVisitorParser** adds the created **JavaItem** to the `javaItems` list.
5. **ClassVisitorParser** checks if the visited class is an **interface** or **class**.
6. **ClassVisitorParser** calls the `visitClassType` method for any nested classes or interfaces in the visited class.
7. **ClassVisitorParser** calls the `visitMethod` method for each method in the visited class.
8. **ClassVisitorParser** calls the `visitField` method for each field in the visited class.

# Clean Interactions

```mermaid
---
title: Clean Interactions
---

sequenceDiagram
    participant ClassVisitorParser
    participant ClassOrInterfaceDeclaration

    ClassVisitorParser->>ClassOrInterfaceDeclaration: visitClass
    ClassVisitorParser->>ClassOrInterfaceDeclaration: extractJavaDoc
    ClassVisitorParser->>ClassOrInterfaceDeclaration: getBodyDefinition
    ClassVisitorParser->>JavaItem: build JavaItem
    ClassVisitorParser->>JavaItem: add to javaItems list
    alt Is Interface
        ClassVisitorParser->>ClassOrInterfaceDeclaration: visitClassType
    alt Is Class
        ClassVisitorParser->>ClassOrInterfaceDeclaration: visitClassType
        ClassVisitorParser->>ClassOrInterfaceDeclaration: visitMethod
    ClassVisitorParser->>ClassOrInterfaceDeclaration: visitField
```

# Final Participants

- ClassVisitorParser
  - visitClass
  - extractJavaDoc
  - getBodyDefinition
  - build JavaItem
  - add to javaItems list
  - visitClassType
  - visitMethod
  - visitField
- ClassOrInterfaceDeclaration

# Plain English Title

Visiting a class (ClassVisitorParser)

# Mermaid Sequence Diagram

```mermaid
---
title: Visiting a class (ClassVisitorParser)
---

sequenceDiagram
    participant ClassVisitorParser
    participant ClassOrInterfaceDeclaration

    ClassVisitorParser->>ClassOrInterfaceDeclaration: visitClass
    ClassVisitorParser->>ClassOrInterfaceDeclaration: extractJavaDoc
    ClassVisitorParser->>ClassOrInterfaceDeclaration: getBodyDefinition
    ClassVisitorParser->>JavaItem: build JavaItem
    ClassVisitorParser->>JavaItem: add to javaItems list
    alt Is Interface
        ClassVisitorParser->>ClassOrInterfaceDeclaration: visitClassType
    alt Is Class
        ClassVisitorParser->>ClassOrInterfaceDeclaration: visitClassType
        ClassVisitorParser->>ClassOrInterfaceDeclaration: visitMethod
    ClassVisitorParser->>ClassOrInterfaceDeclaration: visitField

```