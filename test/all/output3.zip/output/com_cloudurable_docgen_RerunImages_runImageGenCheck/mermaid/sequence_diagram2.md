----
# FIX RAW RESPONSE 3
# Participants

1. RerunImages
2. File
3. System
4. Arrays
5. Collections
6. Collectors
7. StringBuilder

# Validation Fixes
1. Primitive Rule: Remove primitive or basic data types as participants:
   - Remove `File` and `File[]`.
2. No Method Calls in Descriptions Rule: Replace method calls in descriptions:
   - Replace `Create mermaidOutputDir` with `Create mermaid output directory`.
   - Replace `Create imagesOutputDir` with `Create images output directory`.
   - Replace `Call mkdirs()` with `Ensure directories exist`.
   - Replace `Call stream() on mermaidFileArray` with `Extract mermaid files`.
   - Replace `Call map() to get file name` with `Get file names`.
   - Replace `Call map() to remove file extension` with `Remove file extensions`.
   - Replace `Call toSet() for mermaidFiles` with `Create set of mermaid files`.
   - Replace `Call emptySet()` with `Create empty set`.
   - Replace `Call stream() on imageFileArray` with `Extract image files`.
   - Replace `Call map() to get file name` with `Get file names`.
   - Replace `Call map() to remove file extension` with `Remove file extensions`.
   - Replace `Call toSet() for imageFiles` with `Create set of image files`.
   - Replace `Call removeAll() with imageFiles` with `Remove image files from mermaid files`.
   - Replace `Call reRun() for each missing image file` with `Rerun missing image files`.
   - Replace `Print "No mermaid files yet"` with `Print "No mermaid files found"`.
   - Replace `Print "Total mermaid files"` with `Print total number of mermaid files`.
   - Replace `Print "Sizes not equal"` with `Print unequal sizes`.
   - Replace `Print "Missing images"` with `Print missing image files`.

# Interaction After Fix

1. RerunImages->>File: Create mermaid output directory
2. RerunImages->>File: Create images output directory
3. RerunImages->>imagesOutputDir: Ensure directories exist
4. alt mermaidFileArray is null
   - RerunImages-->>System: Print "No mermaid files found" and exit program
5. else mermaidFileArray is not null
   - RerunImages-->>System: Print total number of mermaid files
   - RerunImages->>Arrays: Extract mermaid files
   - RerunImages->>Arrays: Get file names
   - RerunImages->>Arrays: Remove file extensions
   - RerunImages->>Collectors: Create set of mermaid files
   - alt imageFileArray is null
     - RerunImages-->>Collections: Create empty set
   - else imageFileArray is not null
     - RerunImages->>Arrays: Extract image files
     - RerunImages->>Arrays: Get file names
     - RerunImages->>Arrays: Remove file extensions
     - RerunImages->>Collectors: Create set of image files
   - alt size of imageFiles is not equal to size of mermaidFiles
     - RerunImages-->>System: Print unequal sizes
     - RerunImages->>mermaidFiles: Remove image files from mermaid files
     - RerunImages-->>System: Print missing image files
     - RerunImages-->>File: Rerun missing image files
   - end

# Final Participants

1. RerunImages
2. File
3. System
4. Arrays
5. Collections
6. Collectors

# Plain English Title

Rerun Images

# Mermaid Sequence Diagram

```mermaid
---
title: Rerun Images
---

sequenceDiagram
    participant RerunImages
    participant File
    participant System
    participant Arrays
    participant Collections
    participant Collectors
    
    RerunImages->>File: Create mermaid output directory
    RerunImages->>File: Create images output directory
    RerunImages->>imagesOutputDir: Ensure directories exist
    alt mermaidFileArray is null
        RerunImages-->>System: Print "No mermaid files found" and exit program
    else mermaidFileArray is not null
        RerunImages-->>System: Print total number of mermaid files
        RerunImages->>Arrays: Extract mermaid files
        RerunImages->>Arrays: Get file names
        RerunImages->>Arrays: Remove file extensions
        RerunImages->>Collectors: Create set of mermaid files
        alt imageFileArray is null
            RerunImages-->>Collections: Create empty set
        else imageFileArray is not null
            RerunImages->>Arrays: Extract image files
            RerunImages->>Arrays: Get file names
            RerunImages->>Arrays: Remove file extensions
            RerunImages->>Collectors: Create set of image files
        end
        alt size of imageFiles is not equal to size of mermaidFiles
            RerunImages-->>System: Print unequal sizes
            RerunImages->>mermaidFiles: Remove image files from mermaid files
            RerunImages-->>System: Print missing image files
            RerunImages-->>File: Rerun missing image files
        end
    end
```
