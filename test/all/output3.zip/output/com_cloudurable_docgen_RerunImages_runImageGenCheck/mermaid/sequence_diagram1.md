----
# ORIGINAL RESPONSE 
# Participants

- RerunImages
- File
- System
- File[]
- Set
- Arrays
- Collections
- Collectors

# Initial Interactions

1. `RerunImages` calls `File` constructor with `outputDir` parameter to create a `File` object called `mermaidOutputDir`.
2. `RerunImages` calls `File` constructor with `outputDir` and the path "images" to create a `File` object called `imagesOutputDir`.
3. `RerunImages` calls the `mkdirs()` method on `imagesOutputDir`.
4. `RerunImages` calls the `listFiles()` method on `imagesOutputDir` and stores the result in an array called `imageFileArray`.
5. `RerunImages` calls the `listFiles()` method on `mermaidOutputDir` and stores the result in an array called `mermaidFileArray`.
6. `RerunImages` checks if `mermaidFileArray` is `null`.
7. If `mermaidFileArray` is `null`, `RerunImages` prints "No mermaid files yet" and exits the program with status code 2.
8. `RerunImages` prints "Total mermaid files" followed by the length of `mermaidFileArray`.
9. `RerunImages` creates a `Set` called `mermaidFiles` by iterating over `mermaidFileArray`, getting the name of each file, and removing the file extension.
10. `RerunImages` creates a `Set` called `imageFiles` by iterating over `imageFileArray`, getting the name of each file, and removing the file extension. If `imageFileArray` is `null`, an empty set is created instead.
11. `RerunImages` checks if the size of `imageFiles` is not equal to the size of `mermaidFiles`.
12. If the sizes are not equal, `RerunImages` prints "Total mermaid files" followed by the size of `mermaidFiles`, and "Sizes not equal" followed by the difference in sizes between `mermaidFiles` and `imageFiles`.
13. `RerunImages` removes all elements in `mermaidFiles` that are also in `imageFiles`.
14. `RerunImages` prints "Missing images" followed by the path of each missing image file.
15. `RerunImages` calls the `reRun()` method with the corresponding `.mmd` and `.png` file paths for each missing image file.

# Clean Interactions

1. `RerunImages`->>`File`: Create `mermaidOutputDir` with `outputDir` parameter
2. `RerunImages`->>`File`: Create `imagesOutputDir` with `outputDir` and "images" path
3. `RerunImages`->>`imagesOutputDir`: Call `mkdirs()`
4. `RerunImages`->>`imagesOutputDir`: Call `listFiles()`
5. `RerunImages`->>`mermaidOutputDir`: Call `listFiles()`
6. `RerunImages`->>`mermaidFileArray`: Check if `mermaidFileArray` is `null`
7. `RerunImages`-->>`System`: Print "No mermaid files yet" and exit program
8. `RerunImages`-->>`System`: Print "Total mermaid files" and the length of `mermaidFileArray`
9. `RerunImages`->>`Arrays`: Call `stream()` on `mermaidFileArray`
10. `RerunImages`->>`Arrays`: Call `map()` to get the file name of each element in the stream
11. `RerunImages`->>`Arrays`: Call `map()` to remove the file extension from each file name
12. `RerunImages`->>`Collectors`: Call `toSet()` to collect stream elements into a `Set` called `mermaidFiles`
13. `RerunImages`->>`imageFileArray`: Check if `imageFileArray` is `null`
14. `RerunImages`-->>`Collections`: Call `emptySet()` if `imageFileArray` is `null`
15. `RerunImages`->>`imageFileArray`: Call `stream()` on `imageFileArray`
16. `RerunImages`->>`Arrays`: Call `map()` to get the file name of each element in the stream
17. `RerunImages`->>`Arrays`: Call `map()` to remove the file extension from each file name
18. `RerunImages`->>`Collectors`: Call `toSet()` to collect stream elements into a `Set` called `imageFiles`
19. `RerunImages`->>`imageFiles`: Check if the size is not equal to the size of `mermaidFiles`
20. `RerunImages`-->>`System`: Print "Total mermaid files" and the size of `mermaidFiles`
21. `RerunImages`-->>`System`: Print "Sizes not equal" and the difference in sizes
22. `RerunImages`->>`mermaidFiles`: Call `removeAll()` with `imageFiles` as the argument
23. `RerunImages`-->>`System`: Print "Missing images" and the path of each missing image file
24. `RerunImages`-->>`File`: Call `reRun()` with the corresponding `.mmd` and `.png` file paths

# Final Participants

- RerunImages
  - Call `File` constructor
  - Call `mkdirs()`
  - Call `listFiles()`
  - Call `stream()`
  - Call `map()`
  - Call `toSet()`
  - Check if `null`
  - Check if size is not equal
  - Call `removeAll()`
- File
- System
- File[]
- Set
- Arrays
- Collections
- Collectors

# Plain English Title

Rerun Images

# Mermaid Sequence Diagram

```mermaid
---
title: Rerun Images
---

sequenceDiagram
    participant RerunImages
    participant File
    participant System
    participant File[]
    participant Set
    participant Arrays
    participant Collections
    participant Collectors

    RerunImages->>File: Create mermaidOutputDir
    RerunImages->>File: Create imagesOutputDir
    RerunImages->>imagesOutputDir: Call mkdirs()
    alt mermaidFileArray is null
        RerunImages-->>System: Print "No mermaid files yet" and exit program
    else mermaidFileArray is not null
        RerunImages-->>System: Print "Total mermaid files" and length of mermaidFileArray
        RerunImages->>Arrays: Call stream() on mermaidFileArray
        RerunImages->>Arrays: Call map() to get file name
        RerunImages->>Arrays: Call map() to remove file extension
        RerunImages->>Collectors: Call toSet() for mermaidFiles
        alt imageFileArray is null
            RerunImages-->>Collections: Call emptySet()
        else imageFileArray is not null
            RerunImages->>Arrays: Call stream() on imageFileArray
            RerunImages->>Arrays: Call map() to get file name
            RerunImages->>Arrays: Call map() to remove file extension
            RerunImages->>Collectors: Call toSet() for imageFiles
        end
        alt size of imageFiles is not equal to size of mermaidFiles
            RerunImages-->>System: Print "Total mermaid files" and size of mermaidFiles
            RerunImages-->>System: Print "Sizes not equal" and difference in sizes
            RerunImages->>mermaidFiles: Call removeAll() with imageFiles
            RerunImages-->>System: Print "Missing images" and path of each missing image file
            RerunImages-->>File: Call reRun() for each missing image file
        end
    end
```

End of instructions.