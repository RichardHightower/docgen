----
# FIX RAW RESPONSE 3
# Participants
- ClassVisitorParser
- Stream
- CompilationUnit
- JavaItem
- File
- Path

# Validation Fixes
- Remove `File` participant because it is a primitive type.
- Replace `parseFile(file)` with "Parse Java file" to remove method call in the interaction.

# Interaction After Fix
1. ClassVisitorParser creates a Stream from directoryPath.
2. ClassVisitorParser receives successful directory scan from Stream.
3. Stream filters and selects regular Java files.
4. Stream iterates over the selected Java files.
5. ClassVisitorParser parses a Java file.
6. If Java file parsing is successful:
   - ClassVisitorParser creates and parses a CompilationUnit.
   - CompilationUnit extracts Java items.
   - JavaItem is added to javaItems list.
7. If Java file parsing fails:
   - ClassVisitorParser throws an exception.
8. Stream returns the javaItems list to ClassVisitorParser.
9. ClassVisitorParser returns the javaItems list.

# Final Participants
- ClassVisitorParser
- Stream
- CompilationUnit
- JavaItem
- Path

# Plain English Title
Scan Directory

# Mermaid Sequence Diagram
```mermaid
---
title: Scan Directory
---

sequenceDiagram
    participant ClassVisitorParser
    participant Stream
    participant CompilationUnit
    participant JavaItem
    participant Path

    ClassVisitorParser->>Stream: Create Stream from directoryPath
    Stream->>ClassVisitorParser: Directory scan successful
    Stream->>Stream: Filter to select regular Java files
    Stream->>Stream: Iterate over selected Java files
    ClassVisitorParser->>Stream: Parse Java file
    alt Java file parsing successful
        ClassVisitorParser->>CompilationUnit: Create and parse CompilationUnit
        CompilationUnit->>JavaItem: Extract Java items
        JavaItem->>ClassVisitorParser: Add to javaItems
    else Java file parsing failed
        ClassVisitorParser-->>ClassVisitorParser: Throw exception
    end
    Stream->>ClassVisitorParser: Return javaItems list
    ClassVisitorParser-->>ClassVisitorParser: Return javaItems list
```
End of instructions.