----
# ORIGINAL RESPONSE 
# Participants

* FileUtils
* File
* String
* RuntimeException
* Exception


# Initial Interactions

* FileUtils->File: Convert File to Path
* FileUtils-->File: Call toPath() method
* FileUtils-->String: Write String to File
* FileUtils-->java.nio.file.Files: Write String to File as Path
* FileUtils-->>RuntimeException: Throw RuntimeException
* RuntimeException-->>Exception: Catch Exception


# Clean Interactions

* FileUtils->java.nio.file.Files: Write String to File as Path
* alt Write String to File as Path successful
  * java.nio.file.Files->FileUtils: Return
else Write String to File as Path failed
  * java.nio.file.Files-->>Exception: Throw Exception
  * alt Catch Exception
    * Exception->>RuntimeException: Throw RuntimeException


# Final Participants

* FileUtils
  * alt Write String to File as Path successful
    * FileUtils->java.nio.file.Files: Write String to File as Path
  * else Write String to File as Path failed
    * java.nio.file.Files->>Exception
    * alt Catch Exception
      * Exception->>RuntimeException


# Plain English Title

Write File


# Mermaid Sequence Diagram

```mermaid
---
title: Write File
---

sequenceDiagram
  participant FileUtils
  participant File
  participant String
  participant RuntimeException
  participant Exception
  participant java.nio.file.Files
  
  FileUtils->>File: Convert File to Path
  FileUtils->>String: Write String to File
  FileUtils->>java.nio.file.Files: Write String to File as Path
  alt Write String to File as Path successful
    java.nio.file.Files-->>FileUtils: Return
  else Write String to File as Path failed
    java.nio.file.Files-->>Exception: Throw Exception
    alt Catch Exception
      Exception->>RuntimeException: Throw RuntimeException
```
