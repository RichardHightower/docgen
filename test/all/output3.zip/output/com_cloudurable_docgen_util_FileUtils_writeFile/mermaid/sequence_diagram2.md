----
# FIX RAW RESPONSE 3
# Participants

- FileUtils
- File
- java.nio.file.Files

# Validation Fixes

- Remove `String` from participants
- Convert `File` to `Path` for `FileUtils`

# Interaction After Fix

1. `FileUtils` converts `File` to `Path`
2. `FileUtils` writes `String` to `File` using `Path`
3. `FileUtils` calls the `writeString` method of `java.nio.file.Files` to write the `String` to the `File` as a `Path`
4. If the write operation is successful, `java.nio.file.Files` returns the result to `FileUtils`
5. If the write operation fails, `java.nio.file.Files` throws an `Exception`
6. If the `Exception` is caught, it is converted to a `RuntimeException` and thrown

# Final Participants

- FileUtils
- java.nio.file.Files

# Plain English Title

Write File

# Mermaid Sequence Diagram

```mermaid
---
title: Write File
---

sequenceDiagram
  participant FileUtils
  participant java.nio.file.Files
  
  FileUtils->>java.nio.file.Files: Convert File to Path
  FileUtils->>java.nio.file.Files: Write String to File as Path
  alt Write String to File as Path successful
    java.nio.file.Files-->>FileUtils: Return
  else Write String to File as Path failed
    java.nio.file.Files-->>Exception: Throw Exception
    alt Catch Exception
      Exception->>RuntimeException: Throw RuntimeException
```
